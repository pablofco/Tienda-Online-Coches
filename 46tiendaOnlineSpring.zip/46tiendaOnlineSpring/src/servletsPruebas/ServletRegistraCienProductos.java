package servletsPruebas;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import modelo.Producto;
import modelo.Usuario;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import daos.UsuariosDAO;


@WebServlet("/ServletRegistraCienProductos")
public class ServletRegistraCienProductos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		WebApplicationContext contenedor = ContextLoader
				.getCurrentWebApplicationContext();
	
ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		
		for (int i = 0; i < 100; i++) {
			Producto p = new Producto("coche"+i , 10, "grande"+i , "porsche"+i , 100 , "azul"+i);
			dao.registrarProducto(p);
			System.out.println("registrado: " + p.toString());
			
		}//end for
		System.out.println("100 productos registrados");
	}// end service


	}//END CLASS


