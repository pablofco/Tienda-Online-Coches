package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ServletZonaPrivada")
public class ServletZonaPrivada extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// servlet que controla el acceso a la zona privada
		if(request.getSession().getAttribute("idUsuario") != null){
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/zonaPrivada.jsp"); // significa no te quedes en blanco
											// servlet y le mandas el listado al
											// cliente // repartidor de
											// peticiones
		rd.forward(request, response);
	}else{
		request.setAttribute("errorLogin", "Debes indentificarte para entrar aqu�");
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/login.jsp"); // significa no te quedes en blanco
											// servlet y le mandas el listado al
											// cliente // repartidor de
											// peticiones
		rd.forward(request, response);
	}

	}
	}
