package servlet.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.CategoriasDAO;
import daos.UsuariosDAO;


@WebServlet("/ServletBorrarUsuarioAdmin")
public class ServletBorrarUsuarioAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idAborrar  = request.getParameter("id");
		System.out.println("queremos borrar id:" + idAborrar);
		
		WebApplicationContext contenedor = ContextLoader
				.getCurrentWebApplicationContext();
	
		
		UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
		dao.borrarUsuarioPorId(Integer.parseInt(idAborrar));
		
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/admin/ServletListadoUsuarios"); 
		rd.forward(request, response);
	}

}
