package servlet.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;
import modelo.Usuario;


@WebServlet("/admin/ServletRegistroUsuarioAdmin")
public class ServletRegistroUsuarioAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	
		
		String nombre = request.getParameter("campoNombre");
		String email = request.getParameter("campoEmail");
		String pass = request.getParameter("campoPass");
		
		String idCategoria = request.getParameter("campoIdCategoria");
		
		Usuario nuevo = new Usuario (nombre,email,pass);
		nuevo.setIdCategoriaUsuario(Integer.parseInt(idCategoria));
		System.out.println ("voy a registrar: " + nuevo);
		System.out.println("vamos a ver si somos capaces de recuperar un bean del contenedor de spring");
		WebApplicationContext contenedor = ContextLoader.getCurrentWebApplicationContext();
		UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
		dao.registrarUsuario(nuevo);
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/admin/ServletListadoUsuarios");
		rd.forward(request, response);
	}

}
