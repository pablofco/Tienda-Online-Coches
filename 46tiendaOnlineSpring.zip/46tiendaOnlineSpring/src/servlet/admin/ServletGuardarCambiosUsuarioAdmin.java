package servlet.admin;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.UsuariosDAO;
import modelo.Usuario;


@WebServlet("/admin/ServletGuardarCambiosUsuarioAdmin")
public class ServletGuardarCambiosUsuarioAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//recojo la informacion del formulario y la piso en base de datos sobre el id del registro indicado
		
		String nombre = request.getParameter("campoNombre");
		String email = request.getParameter("campoEmail");
		String pass = request.getParameter("campoPass");
		String id = request.getParameter("campoId");
		
		Usuario usuarioAeditar = new Usuario();
		usuarioAeditar.setNombre(nombre);
		usuarioAeditar.setEmail(email);
		usuarioAeditar.setPass(pass);
		usuarioAeditar.setId(Integer.parseInt(id));
		
		WebApplicationContext contenedor = ContextLoader
				.getCurrentWebApplicationContext();
	
		
		UsuariosDAO dao = contenedor.getBean(UsuariosDAO.class);
		dao.actualizarUsuario(usuarioAeditar);
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/admin/ServletListadoUsuarios"); 
		rd.forward(request, response);
		
		
	}

}
