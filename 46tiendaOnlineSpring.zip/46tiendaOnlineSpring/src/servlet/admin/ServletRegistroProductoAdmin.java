package servlet.admin;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import daos.ProductosDAO;
import modelo.Producto;

@WebServlet("/admin/ServletRegistroProductoAdmin")
@MultipartConfig
public class ServletRegistroProductoAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String nombre = request.getParameter("campoNombre");
		String precio = request.getParameter("campoPrecio");
		String tamano = request.getParameter("campoTamano");
		String modelo = request.getParameter("campoModelo");
		String caballos = request.getParameter("campoCaballos");
		String color = request.getParameter("campoColor");
		
		String idCategoria = request.getParameter("campoIdCategoria");
		
		precio = precio.replace(",", ".");
		double precioDouble = Double.parseDouble(precio);
		caballos = caballos.replace(",", ".");
		double caballosDouble = Double.parseDouble(caballos);
		Producto nuevo = new Producto(nombre, precioDouble,tamano, modelo, caballosDouble, color);
		WebApplicationContext contenedor = ContextLoader
				.getCurrentWebApplicationContext();
		// asi le pido al contenedor de spring que nos de la unica bean que tiene de una clase que implemente
		// el interfaz productos DAO, en concreto ahora mismo dao, ser�a la siguiente bean definida en el xml
		
//		<bean id="productosDAO" class="daos.ProductosDAOImpl">
//		<property name="dataSource" ref="miDataSource"/>
//		
//		</bean>
		
		ProductosDAO dao = contenedor.getBean(ProductosDAO.class);
		dao.registrarProducto(nuevo);
		//una vez registrado el producto mosntraremos el listado de productos
		int idGenerado = dao.registrarProducto(nuevo);
		
		
		String rutaArchivo = getServletContext().getRealPath("")+
				"/" + "subidasImagenesProductos";
		File carpeta = new File(rutaArchivo);
		if (! carpeta.exists()) {
			carpeta.mkdir();
		}
		Part campoImagen = request.getPart("campoImagen");
		campoImagen.write(rutaArchivo + "/" + idGenerado + ".jpg");
		System.out.println("archivo subido a la carpeta: " + rutaArchivo);
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher(
				"/admin/ServletListadoProductosAdmin"); 
		rd.forward(request, response);
	}

}
