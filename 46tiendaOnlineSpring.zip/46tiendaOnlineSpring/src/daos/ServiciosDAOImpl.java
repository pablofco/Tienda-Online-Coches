package daos;

import java.util.HashMap;
import java.util.List;



import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Servicio;

public class ServiciosDAOImpl implements ServiciosDAO {

	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getElDataSource(){
		return dataSource;
		
	}
	
	public void setDataSource(DataSource elDataSource){
		this.dataSource = elDataSource;
		
		simpleInsert = new SimpleJdbcInsert(elDataSource);
		simpleInsert.setTableName("tabla_servicios");;
		jdbcTemplate = new JdbcTemplate(elDataSource);
		
		
	}
	
	@Override
	public void registrarServicio(Servicio r) {
		HashMap<String , Object> valores = new HashMap<String, Object>();
		valores.put("nombre", r.getNombre());
		valores.put("descripcion", r.getDescripcion());
		valores.put("precio", r.getPrecio());
		simpleInsert.execute(valores);
	
		
	}

	@Override
	public List<Servicio> obtenerServicios() {
		String sql = ConstantesSQL.SQL_SELECCION_SERVICIOS;
		List<Servicio> servicios = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Servicio.class));
		
		return servicios;
	}
	
	

}
