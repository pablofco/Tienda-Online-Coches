package daos;

import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Producto;

public class ProductosDAOImpl implements ProductosDAO{

	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Override
	public int registrarProducto(Producto p) {
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", p.getNombre());
		valores.put("precio", p.getPrecio());
		valores.put("tama�o", p.getTamano());
		valores.put("modelo", p.getModelo());
		valores.put("caballos", p.getCaballos());
		valores.put("color", p.getColor());
		valores.put("idCategoriaProducto", p.getIdCategoriaProducto());
//		simpleInsert.execute(valores);
		int idGenerado = simpleInsert.executeAndReturnKey(valores).intValue();
		return idGenerado;
	}

	@Override
	public List<Producto> obtenerProductos() {
		String sql = ConstantesSQL.SQL_SELECCION_PRODUCTOS;
		List<Producto> productos = jdbcTemplate.query(sql,
				new BeanPropertyRowMapper(Producto.class));
		return productos;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		simpleInsert = new SimpleJdbcInsert(dataSource);
		simpleInsert.setTableName("tabla_productos");
		simpleInsert.usingGeneratedKeyColumns("id");
		jdbcTemplate = new JdbcTemplate(dataSource);

	}

	@Override
	public Producto obtenerProductoPorId(int id) {
		String valores[] = {String.valueOf(id)};
		Producto producto = (Producto) jdbcTemplate.queryForObject(ConstantesSQL.SQL_OBTENER_PRODUCTO_POR_ID, valores,
				new BeanPropertyRowMapper(Producto.class));
		return producto;
	}

	@Override
	public void actualizarProducto(Producto p) {
		jdbcTemplate.update(ConstantesSQL.SQL_ACTUALIZAR_PRODUCTO, p.getNombre(), p.getPrecio(),p.getTamano(),p.getModelo(),p.getCaballos(),p.getColor(),p.getId());
		
	}

	@Override
	public void borrarProductoPorId(int id) {
		jdbcTemplate.update(ConstantesSQL.SQL_BORRAR_PRODUCTO,id);
		
	}

	@Override
	public int obtenerTotalProductos() {
		int total = jdbcTemplate.queryForInt(ConstantesSQL.SQL_TOTAL_PRODUCTOS);
		return total;
	}

	@Override
	public List<Producto> obtenerProductos(int comienzo, int cuantos) {
		Integer [] valores = {Integer.valueOf(comienzo), Integer.valueOf(cuantos)};
		List<Producto> productos = jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_PRODUCTOS_INICIO_CUANTOS,
				 valores, new BeanPropertyRowMapper(Producto.class));
		return productos;
	}

	@Override
	public List<Producto> obtenerProductos(int comienzo, int cuantos,
			String busqueda) {
		Object [] valores = { "%" + busqueda + "%" , Integer.valueOf(comienzo), Integer.valueOf(cuantos)};
		
		List<Producto> productos = jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_PRODUCTOS_INICIO_CUANTOS_BUSQUEDA,
				valores , new BeanPropertyRowMapper(Producto.class));
		
		return productos;
	}

	@Override
	public int obtenerTotalProductos(String busqueda) {
		int total = jdbcTemplate.queryForInt(ConstantesSQL.SQL_TOTAL_PRODUCTOS_BUSQUEDA, "%" + busqueda + "%");
		return total;
	}



}
