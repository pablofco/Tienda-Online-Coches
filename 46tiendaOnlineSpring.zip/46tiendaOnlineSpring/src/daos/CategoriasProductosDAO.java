package daos;

import java.util.List;

import modelo.CategoriaProducto;

public interface CategoriasProductosDAO {
	
	List<CategoriaProducto> obtenerCategorias();

}
