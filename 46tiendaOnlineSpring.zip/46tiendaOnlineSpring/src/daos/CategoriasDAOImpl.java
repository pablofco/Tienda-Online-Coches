package daos;

import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import constantes.ConstantesSQL;
import modelo.Categoria;

public class CategoriasDAOImpl implements CategoriasDAO{

	private DataSource dataSource;
	private SimpleJdbcInsert simpleInsert;
	private JdbcTemplate jdbcTemplate;
	
	
	
	public DataSource getDataSource(){
		return dataSource;
	}
	
	
	@Override
	public void registrarCategoria(Categoria c) {
		HashMap<String, Object> valores = new HashMap<String, Object>();
		valores.put("nombre", c.getNombre());
		valores.put("descripcion", c.getDescripcion());
		simpleInsert.execute(valores);
	}

	@Override
	public List<Categoria> obtenerCategorias() {
		String sql = ConstantesSQL.SQL_SELECCION_CATEGORIA;
		List<Categoria> categoria = jdbcTemplate.query(sql, new BeanPropertyRowMapper(Categoria.class));
		return categoria;
	}
	
	public void setDataSource(DataSource dataSource){
		this.dataSource = dataSource;
		simpleInsert = new SimpleJdbcInsert(dataSource);
		simpleInsert.setTableName("tabla_categorias");
		jdbcTemplate = new JdbcTemplate(dataSource);
		
	}
	

}
