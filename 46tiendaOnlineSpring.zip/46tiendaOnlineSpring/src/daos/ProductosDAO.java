package daos;

import java.util.List;

import modelo.Producto;

public interface ProductosDAO {

	int registrarProducto(Producto p);

	List<Producto> obtenerProductos();

	void borrarProductoPorId(int id);

	Producto obtenerProductoPorId(int id);

	void actualizarProducto(Producto p);
	
	List<Producto> obtenerProductos(int comienzo, int cuantos);

	
	int obtenerTotalProductos();

	List<Producto> obtenerProductos(int comienzo, int cuantos, String busqueda );
	
	int obtenerTotalProductos(String busqueda);

}
