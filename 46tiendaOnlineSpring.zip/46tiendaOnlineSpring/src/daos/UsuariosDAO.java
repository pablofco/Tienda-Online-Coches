package daos;

import java.util.ArrayList;
import java.util.List;

import modelo.Usuario;

public interface UsuariosDAO {

	int registrarUsuario(Usuario u);

	ArrayList<Usuario> obtenerUsuarios();

	int obtenerIdUsuarioPorEmailYPass(String email, String pass);

	void borrarUsuarioPorId(int id);

	Usuario obtenerUsuarioPorId(int id);

	void actualizarUsuario(Usuario u);

	List<Usuario> obtenerUsuarios(int comienzo, int cuantos);
	
	int obtenerTotalUsuarios();
	
	List<Usuario> obtenerUsuarios(int comienzo, int cuantos, String busqueda);
	
	int obtenerTotalUsuarios(String busqueda);

}
