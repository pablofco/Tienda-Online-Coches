package daos;

import java.util.List;

import modelo.Producto;
import modelo.Servicio;

public interface ServiciosDAO {
	
	void registrarServicio(Servicio nuevo);
	List<Servicio> obtenerServicios();
		

}
