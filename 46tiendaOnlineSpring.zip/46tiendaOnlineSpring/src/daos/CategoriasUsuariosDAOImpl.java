package daos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import constantes.ConstantesSQL;
import modelo.CategoriaUsuario;

public class CategoriasUsuariosDAOImpl implements CategoriasUsuariosDAO{

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource){
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	
	
	@Override
	public List<CategoriaUsuario> obtenerCategorias() {
		List<CategoriaUsuario> categoriasUsuarios = jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_CATEGORIAS_USUARIO,
				new BeanPropertyRowMapper(CategoriaUsuario.class));
		return categoriasUsuarios;
	}

}
