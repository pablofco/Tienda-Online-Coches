package daos;

import java.util.List;

import javax.sql.DataSource;

import modelo.CategoriaProducto;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import constantes.ConstantesSQL;

public class CategoriasProductosDAOImpl implements CategoriasProductosDAO{
	
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource (DataSource dataSource){
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	@Override
	public List<CategoriaProducto> obtenerCategorias() {
		List<CategoriaProducto> categoriasProductos = 
				jdbcTemplate.query(ConstantesSQL.SQL_SELECCION_CATEGORIAS_PRODUCTOS,
				new BeanPropertyRowMapper(CategoriaProducto.class));
		return categoriasProductos;
	}
	

}
